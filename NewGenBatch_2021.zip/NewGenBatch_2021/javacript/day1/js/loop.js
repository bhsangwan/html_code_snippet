
document.writeln("Welcome <br>");

let i = 1;

while (i <= 10){
    document.writeln("Hello"+i+" <br>");

    if(i == 6){
        document.write("The value of i reached " + i +"<br>");
        document.write("Hence continuing loop from test condition<br>");
        i = i+2;
        continue;
    }

    document.write("The value of i "+i+"<br>")

    i++;
} 

document.write("Value of i = "+i+"<br>");

document.writeln("Bye..!<br>");