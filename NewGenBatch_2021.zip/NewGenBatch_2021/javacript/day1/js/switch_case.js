
let val;

val = prompt("Enter the day number: ");

//let num = parseInt(val);

switch(val){
    case "1":
        document.write("Sunday");
    
    case "2":
        document.write("Monday");
        break;
    
    case "3":
        document.write("Tuesday");
        break;

    default:
        document.write("You have enter wrong number");
        break;
}

/* if(val == "1"){

}else if(val == "2"){

} */

document.write("Bye");