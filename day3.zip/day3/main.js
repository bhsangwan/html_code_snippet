let counter = 1;
let animals = document.getElementById("animal-info");
let btn = document.getElementById("btn");
btn.addEventListener("click", function () {
    let ourRequest = new XMLHttpRequest();
    ourRequest.open('GET', 'https://learnwebcode.github.io/json-example/animals-'+counter+'.json');

    ourRequest.onload = function () {
        if(ourRequest.status >= 200 && ourRequest.status < 400){
            let ourData = JSON.parse(ourRequest.responseText);
            console.log(ourData);
            renderHTML(ourData);
        }else {
            console.log("We connected to the server, but it returned an error.");
        }
    };

    counter++;
    ourRequest.send();

    ourRequest.onerror = function () {
        console.log("Connection error");
    };

    if(counter > 3){
       // btn.classList.add("hide-me");
    }
});

function renderHTML(data) {
    
    let htmlString = "";
    
    for (let i = 0; i < data.length; i++) {
        htmlString += "<p>" + data[i].name + " is a " + data[i].species + " that likes to eat ";

        for (let ii = 0; ii < data[i].foods.likes.length; ii++) {
            if (ii == 0) {
                htmlString += data[i].foods.likes[ii];
            } else {
                htmlString += " and " + data[i].foods.likes[ii];
            }
        }
        
        htmlString += ' and dislikes ';

        for (ii = 0; ii < data[i].foods.dislikes.length; ii++) {
            if (ii == 0) {
                htmlString += data[i].foods.dislikes[ii];
            } else {
                htmlString += " and " + data[i].foods.dislikes[ii];
            }
        }
        htmlString += '.</p>';
    }
    //animals.innerHTML(htmlString);
    animals.insertAdjacentHTML("beforeend", htmlString);
}