
//let sum;

function sayHi( name ){
    document.write("Hi "+name+" !");
}

function takeIntegerValueFromUser(){
    val1 = parseInt(prompt("Enter integer value1 :"));
    val2 = parseInt(prompt("Enter integer value2 :"));
}

function calculateSum(val1, val2){
    let sum = val1 + val2;
    return sum;
}

function displayResult(){
    document.write("Sum ="+sum);
}

sayHi("Bhavesh");

//takeIntegerValueFromUser();

//let summ = calculateSum(12, 34);

let addition = calculateSum(10,2);

//displayResult();


