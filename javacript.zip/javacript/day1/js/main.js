

let a = 12, b = 20, c = 18;

if (a>b && a>c)
    document.write("A is greatest number");
else if (b>a && b>c)
    document.write("B is greatest number");
else 
    document.write("C is greatest number");


if(a != b)
    document.write("A is not equal to B");

if(!(a>b))
    document.write("A is not greater than B");