
let fruits = ["Banana", "Orange", "Apple", "Mango"];

//document.write(fruits);

//document.write(fruits[2]);

document.write("Length of fruits array is - "+fruits.length);

document.write("Elements of fruits array are - <br>")



for(let i = 0; i < fruits.length; i++){
    document.write(fruits[i]);
    document.write("<br>");
}

document.write("----------------------------<br>");


for (let f of fruits) {
    document.write( f );
    document.write("<br>");
}

fruits.push("Bingo");

document.write("After push----------------------------<br>");


for (let f of fruits) {
    document.write( f );
    document.write("<br>");
}
fruits.pop();
document.write("After POP----------------------------<br>");


for (let f of fruits) {
    document.write( f );
    document.write("<br>");
}

fruits.unshift("Hello");

document.write("After Shift----------------------------<br>");


for (let f of fruits) {
    document.write( f );
    document.write("<br>");
}