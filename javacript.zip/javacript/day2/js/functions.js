
const PI = 3.14;
//let radius = 5.6;

function calculateCircleArea(radius){
    //let area = PI * radius * radius;

    return PI * radius * radius;
}

