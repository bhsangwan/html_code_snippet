
let user = {
     name: "Bhavesh",
     age: 32,
     address: {
         city: "Delhi",
         pin: 122001
     }
};


let obj = {}; //empty object

obj.p1 = "";

document.write("<br> User object - "+user.name);
document.write("<br> Age -"+user.age);

user.username = "admin@123";

document.write("<br> Username - "+user.username);

document.write("<br> "+user["likes birds"]);

document.write("<br> Is there any property named 'age' in user object ?");
//ocument.write("age" in user);

if("age" in user){
    document.write("Yes");
}else{
    document.write("No");
}

for(let k in user){
    document.write("<br> "+k+" : "+user[k]);
}


document.write("<br>"+user.address.city);