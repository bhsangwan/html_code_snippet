let name = "Bhavesh Sangwan";

let email = "bhsangwan@gmail.com";

let phone = "9813203890";

let line = "The quick brown fox jumps over the little lazy dog.";

let name_ = 'Bhavesh Sangwan';

document.write(line.length);

document.write("Character at 2 index - "+line.charAt(2));

let wordFromLine = line.substring(2, 10);

document.write("<br> Substring -- "+wordFromLine);

document.write("<br> Substring -- "+line.slice(2,10));

document.write("<br> "+line.toUpperCase());

document.write("<br> Is line starts with \"The\" ?" + line.startsWith("The"));

document.write("<br> The character 'q' is stored at index - " + line.indexOf("q"));







